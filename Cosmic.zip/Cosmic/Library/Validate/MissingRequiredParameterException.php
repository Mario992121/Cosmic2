<?php
namespace Library\Validate;

class MissingRequiredParameterException extends \Exception
{
}
