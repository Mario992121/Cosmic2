<?php
namespace Library\Validate;

use Exception;

class RuleNotFoundException extends Exception
{
}
