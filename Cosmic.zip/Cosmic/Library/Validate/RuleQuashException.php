<?php
namespace Library\Validate;

class RuleQuashException extends \Exception
{
}
